enum class MouseButton
{
	Left = 0,
	Right = 1,
	Middle = 2
};