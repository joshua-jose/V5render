class  Directory
{
public:
	static bool Exists(string path);
	static void Create(string path);
	static void Delete(string path);
};