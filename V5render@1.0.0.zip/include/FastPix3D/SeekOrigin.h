enum class SeekOrigin
{
	Begin = SEEK_SET,
	Current = SEEK_CUR,
	End = SEEK_END
};